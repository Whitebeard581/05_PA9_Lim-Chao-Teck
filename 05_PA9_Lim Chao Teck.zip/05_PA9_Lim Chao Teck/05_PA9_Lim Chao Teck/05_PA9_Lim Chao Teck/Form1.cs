﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _05_PA9_Lim_Chao_Teck
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_convert_Click(object sender, EventArgs e)
        {
            double AmountEntered;
            double Convertedvalue;
            try
            {
            //checking for null values
            if((rdb_USdollars.Checked == false) || (rdb_JapaneseYen.Checked == false))
            {
                txt_convertedAmt.Text = "Select at least one type of currency to convert";
            }
            //convert SGD to US dollars
            if(rdb_USdollars.Checked == true)
            {
                AmountEntered = double.Parse(txt_amount.Text);
                Convertedvalue = AmountEntered * 0.74;

                txt_convertedAmt.Text = Convertedvalue.ToString();
            }
            //convert SGD to Yen dollars
            if (rdb_JapaneseYen.Checked == true)
            {
                AmountEntered = double.Parse(txt_amount.Text);
                Convertedvalue = AmountEntered * 81.97;

                txt_convertedAmt.Text = Convertedvalue.ToString();
            }
            
            if(rdb_MalaysianRinggit.Checked == true)
                {
                    AmountEntered = double.Parse(txt_amount.Text);
                    Convertedvalue = AmountEntered * 3.01;

                    txt_convertedAmt.Text = Convertedvalue.ToString();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid amount");
            }
        }

        private void rdb_JapaneseYen_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_amount.Clear();
            txt_convertedAmt.Clear();

            if(rdb_USdollars.Checked)
            {
                rdb_USdollars.Checked = false;
            }

            else if(rdb_JapaneseYen.Checked)
            {
                rdb_JapaneseYen.Checked = false;
            }
        }
    }
    
}
